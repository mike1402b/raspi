****************************************
* Arduino LCD I2C Library
* This an Arduino library to drive a LCD by I2C protocol.
*
* Nicolas BOUTIN
* boutwork@gmail.com
*
****************************************
Hardware : 
CLCD204 http://www.lextronic.fr/P55-afficheur-4-x-20-caracteres-retro-eclaire-bleu.html
Arduino Uno R3

For details about the code and how to use it, please visit : 
http://playground.arduino.cc//Main/LCDI2C
Video demo : http://www.youtube.com/watch?v=zqLFZlWFROQ

Feel free to ask for help or to suggest improvement...
